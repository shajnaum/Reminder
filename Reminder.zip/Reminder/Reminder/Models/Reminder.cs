﻿using System;

namespace Reminder.Models
{
    public class Reminder
    {
        public DateTime ReminderDateTimeTime { get; set; }

        public string Message { get; set; }
    }
}